from tkinter import *

window = Tk()
window.title("윈도창 연습")
window.geometry("400x100")
window.resizable(width=FALSE, height=FALSE)

window.mainloop()
