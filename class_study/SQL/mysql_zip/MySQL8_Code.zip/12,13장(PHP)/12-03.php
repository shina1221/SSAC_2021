<?php
  $a = 100;
  print $a;
  
  $b = "안녕하세요? MySQL";
  echo $b;
?>