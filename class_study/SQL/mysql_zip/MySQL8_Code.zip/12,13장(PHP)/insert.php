<HTML>
<HEAD>
<META http-equiv="content-type" content="text/html; charset=utf-8">
</HEAD>
<BODY>

<h1> 신규 회원 입력 </h1>
<FORM METHOD="post"  ACTION="insert_result.php">
	아이디 : <INPUT TYPE ="text" NAME="userID"> <br>
	이름 : <INPUT TYPE ="text" NAME="name"> <br> 
	출생년도 : <INPUT TYPE ="text" NAME="birthYear"> <br>
	지역 : <INPUT TYPE ="text" NAME="addr"> <br>
	휴대폰 국번 : <INPUT TYPE ="text" NAME="mobile1"> <br>
	휴대폰 전화번호 : <INPUT TYPE ="text" NAME="mobile2"> <br>
	신장 : <INPUT TYPE ="text" NAME="height"><br>
	<BR><BR>
	<INPUT TYPE="submit"  VALUE="회원 입력">
</FORM>

</BODY>
</HTML>