<?php
 $a = 123;		echo gettype($a), "<br>";
 $a = 123.123; 	echo gettype($a), "<br>";
 $a = "MySQL";	echo gettype($a), "<br>";
 $a = true;		echo gettype($a), "<br>";
 $a = array( 1, 2, 3); echo gettype($a), "<br>";
 ?>