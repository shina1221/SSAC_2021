<?php
   $num1 = 100;
   $num2 = 200;   
   $sum = $num1 + $num2;
?>

<HTML>
<HEAD>
<META http-equiv="content-type" content="text/html; charset=utf-8">
</HEAD>
<BODY>

<h1> 계산 결과는 <?php echo $sum ?> 입니다. </h1>

</BODY>
</HTML>