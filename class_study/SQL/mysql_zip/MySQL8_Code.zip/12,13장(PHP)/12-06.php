<?php
   $a=100;
   $b=200;
   
   if($a > $b) {
	   echo "a가 b보다 큽니다.";
   } else {
	   echo "a가 b보다 작습니다.";
   }
 ?>