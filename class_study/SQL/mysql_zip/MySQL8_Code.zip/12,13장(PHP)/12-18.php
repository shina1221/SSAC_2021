<HTML>
<HEAD>
<META http-equiv="content-type" content="text/html; charset=utf-8">
</HEAD>
<BODY>

<h1> 이 파일은 *.PHP 입니다. </h1>

</BODY>
</HTML>